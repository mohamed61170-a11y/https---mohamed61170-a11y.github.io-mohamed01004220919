document.getElementById("contact").addEventListener("submit", function (e) {
  e.preventDefault();
  document.getElementById("status").textContent = "Thanks, we will be in touch.";
});
